#include <iostream>

using namespace std;

int main() {
    // How many undergraduates does it take to screw in a lightbulb?
    cout << "One - but it might take them five years to do it!\n";
    return 0;
}
